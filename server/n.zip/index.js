require('dotenv').config();
const express = require('express');
const chalk = require('chalk');
const cors = require('cors');
const helmet = require('helmet');

const keys = require('./config/keys');
const routes = require('./routes');
const socket = require('./socket');
const setupDB = require('./utils/db');

const { port } = keys;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  helmet({
    contentSecurityPolicy: false,
    frameguard: true
  })
);
app.use(cors());

// Initialize passport
require('./config/passport')(app);

// Routes
app.use(routes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(chalk.red('Error:'), err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const startServer = async () => {
  try {
    // Connect to database
    await setupDB();
    
    // Start listening
    const server = app.listen(port, () => {
      console.log(
        `${chalk.green('✓')} ${chalk.blue(
          `Server is running on port ${port}`
        )}`
      );
      console.log(
        `${chalk.green('✓')} ${chalk.blue(
          `Visit http://localhost:${port}/ in your browser`
        )}`
      );
      console.log(
        `${chalk.green('✓')} ${chalk.blue(
          `API available at http://localhost:${port}${keys.app.apiURL}`
        )}`
      );
    });

    // Initialize socket.io
    socket(server);
  } catch (error) {
    console.error(chalk.red('✗ Failed to start server:'), error);
    process.exit(1);
  }
};

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error(chalk.red('Unhandled Promise Rejection:'), err);
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error(chalk.red('Uncaught Exception:'), err);
  process.exit(1);
});

// Start the application
startServer();
